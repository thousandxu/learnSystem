// var layer = require( "../layer" );
// var timeline =require( "../timeline" );

// var text, fps = "fps: ";

// exports.set = function(){
// 	text = layer.createText( "default", fps + "0", 4, 470 ).attr( "fill", "#ccc" );
// };

// exports.update = function(){
// 	text.attr( "text", fps + ( timeline.getFPS() >> 0 ) );
// };